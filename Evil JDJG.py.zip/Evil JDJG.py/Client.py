from typing_extensions import runtime
import nextcord

## make sure to add the bot token to the nextcord.py file
# design a way to add the bot token to the nextcord.py file
def main(): {
    nextcord.run()
}
print(main)
import os
## JDJG 9000 V1.0A - EVIL JDGJG - JDJG (C) 2021
import sys
import time
from nextcord.ext.commands import bot
import nextcord.utils as utils
import nextcord 
import nextcord.utils as utils

## import the token from the token.txt
token = open("token.txt", "r")
## load the token
token = token.read()
## make the bot go online from the token
nextcord.run(token)
nextcord = nextcord.Client()
def bot_start(): {
     nextcord.run() ## this starts the bot 
    @nextcord.command(name='start')

    ## launch the program using the token

## slash command to manage the bot
}
print(bot_start)

def bot_stop(): {
nextcord.stop() ## this stops the bot
@nextcord.command(name='stop', aliases=['shutdown'])
}

def bot_restart(): {
nextcord.restart() ## this restarts the bot
@nextcord.command(name='restart', aliases=['reboot'])
}


def bot_status(): {
nextcord.status() ## this shows the bot status
@nextcord.command(name='status')
}


def bot_Copyright(): {
nextcord.Copyright() ## this shows the bot copyright
@nextcord.command(name='(C) - Flames Co. LLC)')

 
}